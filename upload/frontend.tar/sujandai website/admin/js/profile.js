/**
 * ====================================================================
 * WEDDING MOMENT NEPAL - PROFILE CONTROLLER (profile.js)
 * ====================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
    renderSharedLayout('My Profile');

    /*
     * REAL BACKEND STEP:
     * // API ENDPOINT: GET /api/v1/auth/me
     * fetch('/api/v1/auth/me', { credentials: 'include' })
     *   .then(r => r.json()).then(data => loadProfile(data));
     */

    const user = checkAuth(true);
    if (!user) return;

    loadProfile(user);

    document.getElementById('profile-form')?.addEventListener('submit', saveProfile);
    document.getElementById('password-form')?.addEventListener('submit', changePassword);
    document.getElementById('avatar-input')?.addEventListener('change', handleAvatarPreview);
});

function loadProfile(user) {
    setValue('profile-name', user.name || user.username || 'Admin');
    setValue('profile-email', user.email || '');
    setValue('profile-role', user.role || 'Super Admin');

    const avatarImg = document.getElementById('avatar-preview');
    if (avatarImg && user.avatar) avatarImg.src = user.avatar;

    const nameDisplay = document.getElementById('profile-name-display');
    const roleDisplay = document.getElementById('profile-role-display');
    if (nameDisplay) nameDisplay.textContent = user.name || user.username;
    if (roleDisplay) roleDisplay.textContent = user.role || 'Administrator';
}

function setValue(id, val) {
    const el = document.getElementById(id);
    if (el) el.value = val || '';
}

function handleAvatarPreview(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
        const img = document.getElementById('avatar-preview');
        if (img) img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
}

function saveProfile(e) {
    e.preventDefault();

    const name = document.getElementById('profile-name')?.value.trim();
    const email = document.getElementById('profile-email')?.value.trim();

    if (!name || !email) {
        showToast('Name and email cannot be empty.', 'danger');
        return;
    }

    /*
     * REAL BACKEND STEP:
     * // API ENDPOINT: PUT /api/v1/users/me
     * const formData = new FormData(document.getElementById('profile-form'));
     * fetch('/api/v1/users/me', { method: 'PUT', body: formData });
     */

    // Update localStorage mock session
    const sessionRaw = localStorage.getItem('wedding_admin_session');
    if (sessionRaw) {
        const session = JSON.parse(sessionRaw);
        session.name = name;
        session.email = email;
        localStorage.setItem('wedding_admin_session', JSON.stringify(session));
    }

    document.getElementById('profile-name-display').textContent = name;
    showToast('Profile updated successfully!', 'success');
}

function changePassword(e) {
    e.preventDefault();

    const current = document.getElementById('current-password')?.value;
    const newPass = document.getElementById('new-password')?.value;
    const confirm = document.getElementById('confirm-password')?.value;

    if (!current || !newPass || !confirm) {
        showToast('Please fill in all password fields.', 'danger');
        return;
    }

    if (newPass !== confirm) {
        showToast('New password and confirmation do not match.', 'danger');
        return;
    }

    if (newPass.length < 6) {
        showToast('Password must be at least 6 characters.', 'danger');
        return;
    }

    /*
     * REAL BACKEND STEP:
     * // API ENDPOINT: POST /api/v1/auth/change-password
     * fetch('/api/v1/auth/change-password', {
     *     method: 'POST',
     *     headers: { 'Content-Type': 'application/json' },
     *     body: JSON.stringify({ currentPassword: current, newPassword: newPass })
     * });
     */

    document.getElementById('password-form').reset();
    showToast('Password changed successfully! (Mock only — not persisted)', 'success');
}
