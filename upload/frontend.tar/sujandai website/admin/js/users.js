/**
 * ====================================================================
 * WEDDING MOMENT NEPAL - USER MANAGEMENT CONTROLLER (users.js)
 * ====================================================================
 * Features:
 * 1. User List Table Rendering & Pagination/Count
 * 2. Real-time Search by Name & Email
 * 3. Filter by Role & Status
 * 4. Column Sorting (Ascending / Descending)
 * 5. Add / Edit / Delete Modal Management (In-memory mock state)
 * ====================================================================
 */

// Initial Mock Users Data
let mockUsers = [
    { id: 1, name: 'Sujan Shrestha', email: 'admin@weddingmoment.np', role: 'Super Admin', status: 'Active', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80' },
    { id: 2, name: 'Bikas Gurung', email: 'bikas@weddingmoment.np', role: 'Lead Photographer', status: 'Active', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80' },
    { id: 3, name: 'Anita Maharjan', email: 'anita@weddingmoment.np', role: 'Senior Editor', status: 'Active', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80' },
    { id: 4, name: 'Suman Karki', email: 'suman@weddingmoment.np', role: 'Videographer', status: 'Inactive', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80' },
    { id: 5, name: 'Pooja Thapa', email: 'pooja.client@gmail.com', role: 'Client', status: 'Active', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&auto=format&fit=crop&q=80' },
    { id: 6, name: 'Ramesh Adhikari', email: 'ramesh.photo@gmail.com', role: 'Assistant Photographer', status: 'Active', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&auto=format&fit=crop&q=80' }
];

// State variables for sorting and filtering
let currentSortColumn = 'id';
let currentSortDirection = 'asc'; // 'asc' or 'desc'
let editingUserId = null;

document.addEventListener('DOMContentLoaded', () => {
    // Ensure shared layout is rendered
    renderSharedLayout('User Management');

    /* 
     * REAL BACKEND STEP:
     * // API ENDPOINT: GET /api/v1/users
     * fetch('/api/v1/users')
     *   .then(res => res.json())
     *   .then(data => { mockUsers = data; renderUsersTable(); });
     */

    // Event Listeners for Filters & Search
    document.getElementById('user-search-input')?.addEventListener('input', renderUsersTable);
    document.getElementById('role-filter')?.addEventListener('change', renderUsersTable);
    document.getElementById('status-filter')?.addEventListener('change', renderUsersTable);

    // Initial render
    renderUsersTable();
});

/**
 * Filter, Sort, and Render Users Table
 */
function renderUsersTable() {
    const tbody = document.getElementById('users-tbody');
    const userCountEl = document.getElementById('user-count');
    if (!tbody) return;

    const searchVal = document.getElementById('user-search-input')?.value.toLowerCase().trim() || '';
    const roleVal = document.getElementById('role-filter')?.value || 'all';
    const statusVal = document.getElementById('status-filter')?.value || 'all';

    // 1. Filter
    let filtered = mockUsers.filter(u => {
        const matchesSearch = u.name.toLowerCase().includes(searchVal) || u.email.toLowerCase().includes(searchVal);
        const matchesRole = roleVal === 'all' || u.role === roleVal;
        const matchesStatus = statusVal === 'all' || u.status === statusVal;
        return matchesSearch && matchesRole && matchesStatus;
    });

    // 2. Sort
    filtered.sort((a, b) => {
        let valA = a[currentSortColumn];
        let valB = b[currentSortColumn];

        if (typeof valA === 'string') valA = valA.toLowerCase();
        if (typeof valB === 'string') valB = valB.toLowerCase();

        if (valA < valB) return currentSortDirection === 'asc' ? -1 : 1;
        if (valA > valB) return currentSortDirection === 'asc' ? 1 : -1;
        return 0;
    });

    // Update count display
    if (userCountEl) userCountEl.textContent = `Showing ${filtered.length} of ${mockUsers.length} Users`;

    // 3. Render HTML
    if (filtered.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" style="text-align: center; padding: 2.5rem; color: var(--text-muted);">
                    <i class="fa-solid fa-user-slash" style="font-size: 2rem; margin-bottom: 0.5rem; display: block; color: var(--border-color-light);"></i>
                    No users found matching the selected criteria.
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = filtered.map(u => `
        <tr>
            <td>#${u.id}</td>
            <td>
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <img src="${u.avatar}" alt="${escapeHtml(u.name)}" style="width: 36px; height: 36px; border-radius: 50%; object-fit: cover; border: 1px solid var(--primary-gold);">
                    <strong style="color: var(--text-main);">${escapeHtml(u.name)}</strong>
                </div>
            </td>
            <td>${escapeHtml(u.email)}</td>
            <td><span class="badge badge-info">${escapeHtml(u.role)}</span></td>
            <td>
                <span class="badge ${u.status === 'Active' ? 'badge-success' : 'badge-danger'}">
                    ${u.status}
                </span>
            </td>
            <td>
                <div style="display: flex; gap: 0.5rem;">
                    <button class="btn btn-secondary btn-sm" onclick="openEditUserModal(${u.id})" title="Edit User">
                        <i class="fa-solid fa-pen-to-square"></i>
                    </button>
                    <button class="btn btn-danger btn-sm" onclick="deleteUser(${u.id})" title="Delete User">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
}

/**
 * Handle Column Sorting Trigger
 */
function sortUsers(column) {
    if (currentSortColumn === column) {
        currentSortDirection = currentSortDirection === 'asc' ? 'desc' : 'asc';
    } else {
        currentSortColumn = column;
        currentSortDirection = 'asc';
    }

    // Update Header Sort Icons
    document.querySelectorAll('#users-table th.sortable').forEach(th => {
        const icon = th.querySelector('.sort-icon');
        if (icon) {
            if (th.dataset.col === column) {
                icon.className = `sort-icon fa-solid ${currentSortDirection === 'asc' ? 'fa-sort-up' : 'fa-sort-down'}`;
                icon.style.color = 'var(--primary-gold)';
            } else {
                icon.className = 'sort-icon fa-solid fa-sort';
                icon.style.color = 'var(--text-muted)';
            }
        }
    });

    renderUsersTable();
}

/**
 * Open Add User Modal
 */
function openAddUserModal() {
    editingUserId = null;
    document.getElementById('user-modal-title').textContent = 'Add New Staff / User';
    document.getElementById('user-form').reset();
    document.getElementById('user-id').value = '';
    document.getElementById('user-modal-overlay').classList.add('active');
}

/**
 * Open Edit User Modal with existing data
 */
function openEditUserModal(id) {
    const user = mockUsers.find(u => u.id === id);
    if (!user) return;

    editingUserId = id;
    document.getElementById('user-modal-title').textContent = `Edit User: ${user.name}`;
    document.getElementById('user-id').value = user.id;
    document.getElementById('user-name-input').value = user.name;
    document.getElementById('user-email-input').value = user.email;
    document.getElementById('user-role-select').value = user.role;
    document.getElementById('user-status-select').value = user.status;

    document.getElementById('user-modal-overlay').classList.add('active');
}

/**
 * Close User Modal
 */
function closeUserModal() {
    document.getElementById('user-modal-overlay').classList.remove('active');
}

/**
 * Submit User Form (Add / Edit)
 */
function saveUser(e) {
    e.preventDefault();

    const name = document.getElementById('user-name-input').value.trim();
    const email = document.getElementById('user-email-input').value.trim();
    const role = document.getElementById('user-role-select').value;
    const status = document.getElementById('user-status-select').value;

    if (!name || !email) {
        showToast('Please fill in all required fields.', 'danger');
        return;
    }

    if (editingUserId) {
        /* 
         * REAL BACKEND STEP:
         * // API ENDPOINT: PUT /api/v1/users/:id
         * fetch(`/api/v1/users/${editingUserId}`, {
         *     method: 'PUT',
         *     headers: { 'Content-Type': 'application/json' },
         *     body: JSON.stringify({ name, email, role, status })
         * })
         */
        const index = mockUsers.findIndex(u => u.id === editingUserId);
        if (index !== -1) {
            mockUsers[index] = { ...mockUsers[index], name, email, role, status };
            showToast(`User '${name}' updated successfully!`, 'success');
        }
    } else {
        /* 
         * REAL BACKEND STEP:
         * // API ENDPOINT: POST /api/v1/users
         * fetch('/api/v1/users', {
         *     method: 'POST',
         *     headers: { 'Content-Type': 'application/json' },
         *     body: JSON.stringify({ name, email, role, status })
         * })
         */
        const newId = mockUsers.length > 0 ? Math.max(...mockUsers.map(u => u.id)) + 1 : 1;
        const newUser = {
            id: newId,
            name,
            email,
            role,
            status,
            avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80'
        };
        mockUsers.unshift(newUser);
        showToast(`New user '${name}' added successfully!`, 'success');
    }

    closeUserModal();
    renderUsersTable();
}

/**
 * Delete User
 */
function deleteUser(id) {
    const user = mockUsers.find(u => u.id === id);
    if (!user) return;

    if (confirm(`Are you sure you want to delete user '${user.name}'?`)) {
        /* 
         * REAL BACKEND STEP:
         * // API ENDPOINT: DELETE /api/v1/users/:id
         * fetch(`/api/v1/users/${id}`, { method: 'DELETE' })
         */
        mockUsers = mockUsers.filter(u => u.id !== id);
        showToast(`User '${user.name}' deleted.`, 'danger');
        renderUsersTable();
    }
}
