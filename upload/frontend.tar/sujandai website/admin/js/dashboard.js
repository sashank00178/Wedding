/**
 * ====================================================================
 * WEDDING MOMENT NEPAL - DASHBOARD CONTROLLER (dashboard.js)
 * ====================================================================
 * Features:
 * 1. KPI Summary statistics setup
 * 2. Chart.js Line chart (Bookings Over Time)
 * 3. Chart.js Doughnut chart (Service Popularity)
 * 4. Recent Bookings Table Renderer
 * ====================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
    // Ensure shared layout is rendered
    renderSharedLayout('Dashboard Overview');

    /*
     * Backend API Integration Note:
     * Currently using mock JSON objects for dashboard data.
     * -------------------------------------------------------------
     * REAL BACKEND STEP:
     * Fetch KPI stats and chart data from REST endpoints:
     * // API ENDPOINT: GET /api/v1/dashboard/stats
     * // API ENDPOINT: GET /api/v1/dashboard/charts
     * // API ENDPOINT: GET /api/v1/bookings/recent?limit=5
     */

    initLineChart();
    initDoughnutChart();
    renderRecentBookings();
});

/**
 * Initialize Line Chart: Bookings & Revenue Trend
 */
function initLineChart() {
    const ctx = document.getElementById('bookingsTrendChart');
    if (!ctx) return;

    // Custom gradient for gold line chart fill
    const canvas = ctx.getContext('2d');
    const gradient = canvas.createLinearGradient(0, 0, 0, 300);
    gradient.addColorStop(0, 'rgba(212, 175, 55, 0.4)');
    gradient.addColorStop(1, 'rgba(212, 175, 55, 0.0)');

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'Bookings (2026)',
                data: [12, 19, 15, 25, 32, 28, 38, 42, 35, 48, 55, 60],
                borderColor: '#d4af37',
                backgroundColor: gradient,
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#d4af37',
                pointBorderColor: '#151c2c',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    labels: { color: '#94a3b8', font: { family: 'Montserrat' } }
                },
                tooltip: {
                    backgroundColor: '#151c2c',
                    titleColor: '#d4af37',
                    bodyColor: '#f8fafc',
                    borderColor: '#26334d',
                    borderWidth: 1,
                    padding: 12,
                    displayColors: false
                }
            },
            scales: {
                x: {
                    grid: { color: '#1e293b' },
                    ticks: { color: '#94a3b8', font: { family: 'Montserrat' } }
                },
                y: {
                    grid: { color: '#1e293b' },
                    ticks: { color: '#94a3b8', font: { family: 'Montserrat' } },
                    beginAtZero: true
                }
            }
        }
    });
}

/**
 * Initialize Doughnut Chart: Service Popularity
 */
function initDoughnutChart() {
    const ctx = document.getElementById('servicePopularityChart');
    if (!ctx) return;

    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Full Wedding Package', 'Pre-Wedding Shoot', 'Cinematic Video', 'Reception & Rituals'],
            datasets: [{
                data: [45, 25, 20, 10],
                backgroundColor: [
                    '#d4af37', // Gold
                    '#3b82f6', // Blue
                    '#10b981', // Emerald Green
                    '#f59e0b'  // Amber
                ],
                borderColor: '#151c2c',
                borderWidth: 3,
                hoverOffset: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: '#94a3b8', padding: 15, font: { family: 'Montserrat', size: 11 } }
                },
                tooltip: {
                    backgroundColor: '#151c2c',
                    titleColor: '#d4af37',
                    bodyColor: '#f8fafc',
                    borderColor: '#26334d',
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            return ` ${context.label}: ${context.raw}%`;
                        }
                    }
                }
            },
            cutout: '70%'
        }
    });
}

/**
 * Render Recent Bookings Table
 */
function renderRecentBookings() {
    const tbody = document.getElementById('recent-bookings-tbody');
    if (!tbody) return;

    /* Mock Recent Bookings Data */
    const recentBookings = [
        {
            id: 'WM-2026-089',
            client: 'Aayush & Smriti',
            service: 'Full Royal Wedding Package',
            date: '2026-08-15',
            amount: 'Rs. 1,80,000',
            status: 'Confirmed',
            badge: 'badge-success'
        },
        {
            id: 'WM-2026-088',
            client: 'Rohan & Priya',
            service: 'Pre-Wedding Outdoor Shoot',
            date: '2026-08-18',
            amount: 'Rs. 45,000',
            status: 'Pending',
            badge: 'badge-warning'
        },
        {
            id: 'WM-2026-087',
            client: 'Kiran & Sneha',
            service: 'Cinematic Teaser & Photo',
            date: '2026-08-22',
            amount: 'Rs. 1,20,000',
            status: 'Confirmed',
            badge: 'badge-success'
        },
        {
            id: 'WM-2026-086',
            client: 'Bibek & Puja',
            service: 'Engagement & Reception Package',
            date: '2026-08-25',
            amount: 'Rs. 65,000',
            status: 'Completed',
            badge: 'badge-info'
        },
        {
            id: 'WM-2026-085',
            client: 'Manish & Archana',
            service: 'Full Royal Wedding Package',
            date: '2026-09-02',
            amount: 'Rs. 1,95,000',
            status: 'Pending',
            badge: 'badge-warning'
        }
    ];

    tbody.innerHTML = recentBookings.map(b => `
        <tr>
            <td><strong>#${b.id}</strong></td>
            <td>
                <div style="font-weight: 600;">${escapeHtml(b.client)}</div>
            </td>
            <td>${escapeHtml(b.service)}</td>
            <td><i class="fa-regular fa-calendar-days" style="color: var(--primary-gold); margin-right: 5px;"></i> ${b.date}</td>
            <td style="font-weight: 600; color: var(--primary-gold);">${b.amount}</td>
            <td><span class="badge ${b.badge}">${b.status}</span></td>
            <td>
                <a href="orders.html" class="btn btn-secondary btn-sm" title="View Details">
                    <i class="fa-solid fa-eye"></i> View
                </a>
            </td>
        </tr>
    `).join('');
}
