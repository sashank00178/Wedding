/**
 * ====================================================================
 * WEDDING MOMENT NEPAL - ORDERS/BOOKINGS CONTROLLER (orders.js)
 * ====================================================================
 */

let mockOrders = [
    { id: 'WM-2026-089', client: 'Aayush & Smriti Shrestha', email: 'aayush@gmail.com', service: 'Royal Wedding Package', date: '2026-08-15', amount: 180000, status: 'Confirmed' },
    { id: 'WM-2026-088', client: 'Rohan & Priya Karmacharya', email: 'rohan@gmail.com', service: 'Pre-Wedding Outdoor Shoot', date: '2026-08-18', amount: 45000, status: 'Pending' },
    { id: 'WM-2026-087', client: 'Kiran & Sneha Thapa', email: 'kiran@gmail.com', service: 'Cinematic Wedding Film', date: '2026-08-22', amount: 120000, status: 'Confirmed' },
    { id: 'WM-2026-086', client: 'Bibek & Puja Adhikari', email: 'bibek@gmail.com', service: 'Engagement & Reception', date: '2026-08-25', amount: 65000, status: 'Completed' },
    { id: 'WM-2026-085', client: 'Manish & Archana Maharjan', email: 'manish@gmail.com', service: 'Royal Wedding Package', date: '2026-09-02', amount: 195000, status: 'Pending' },
    { id: 'WM-2026-084', client: 'Rajan & Deepa Gurung', email: 'rajan@gmail.com', service: 'Studio Portrait Session', date: '2026-09-05', amount: 15000, status: 'Completed' },
    { id: 'WM-2026-083', client: 'Sagar & Riya Tamang', email: 'sagar@gmail.com', service: 'Destination Wedding Nepal', date: '2026-09-10', amount: 350000, status: 'Cancelled' },
    { id: 'WM-2026-082', client: 'Pratik & Nisha Rana', email: 'pratik@gmail.com', service: 'Pre-Wedding Outdoor Shoot', date: '2026-09-15', amount: 45000, status: 'Confirmed' },
];

const STATUS_BADGE = {
    Confirmed: 'badge-success',
    Pending: 'badge-warning',
    Completed: 'badge-info',
    Cancelled: 'badge-danger'
};

document.addEventListener('DOMContentLoaded', () => {
    renderSharedLayout('Bookings & Orders');

    /*
     * REAL BACKEND STEP:
     * // API ENDPOINT: GET /api/v1/orders?status=&date_from=&date_to=
     * fetch('/api/v1/orders').then(r => r.json()).then(data => { mockOrders = data; renderOrders(); });
     */

    document.getElementById('order-search')?.addEventListener('input', renderOrders);
    document.getElementById('order-status-filter')?.addEventListener('change', renderOrders);
    document.getElementById('order-date-filter')?.addEventListener('change', renderOrders);

    renderOrders();
});

function renderOrders() {
    const tbody = document.getElementById('orders-tbody');
    const countEl = document.getElementById('order-count');
    if (!tbody) return;

    const search = document.getElementById('order-search')?.value.toLowerCase().trim() || '';
    const statusFilter = document.getElementById('order-status-filter')?.value || 'all';
    const dateFilter = document.getElementById('order-date-filter')?.value || '';

    let filtered = mockOrders.filter(o => {
        const matchSearch = o.client.toLowerCase().includes(search) || o.id.toLowerCase().includes(search) || o.service.toLowerCase().includes(search);
        const matchStatus = statusFilter === 'all' || o.status === statusFilter;
        const matchDate = !dateFilter || o.date === dateFilter;
        return matchSearch && matchStatus && matchDate;
    });

    if (countEl) countEl.textContent = `Showing ${filtered.length} of ${mockOrders.length} Bookings`;

    if (filtered.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" style="text-align:center;padding:2.5rem;color:var(--text-muted);">
                    <i class="fa-solid fa-calendar-xmark" style="font-size:2rem;display:block;margin-bottom:0.5rem;color:var(--border-color-light);"></i>
                    No bookings match your current filters.
                </td>
            </tr>`;
        return;
    }

    tbody.innerHTML = filtered.map(o => `
        <tr id="row-${o.id.replace(/-/g, '_')}">
            <td><strong style="color:var(--primary-gold);">#${o.id}</strong></td>
            <td>
                <div style="font-weight:600;">${escapeHtml(o.client)}</div>
                <div style="font-size:0.78rem;color:var(--text-muted);">${escapeHtml(o.email)}</div>
            </td>
            <td>${escapeHtml(o.service)}</td>
            <td><i class="fa-regular fa-calendar" style="color:var(--primary-gold);margin-right:5px;"></i>${o.date}</td>
            <td style="font-weight:700;color:var(--text-main);">Rs. ${o.amount.toLocaleString('ne-NP')}</td>
            <td>
                <select class="form-control" style="width:auto;padding:0.35rem 0.6rem;font-size:0.82rem;" onchange="changeOrderStatus('${o.id}', this.value)">
                    ${['Pending','Confirmed','Completed','Cancelled'].map(s =>
                        `<option value="${s}" ${o.status === s ? 'selected' : ''}>${s}</option>`
                    ).join('')}
                </select>
            </td>
            <td><span class="badge ${STATUS_BADGE[o.status]}" id="status-badge-${o.id.replace(/-/g,'_')}">${o.status}</span></td>
        </tr>
    `).join('');
}

function changeOrderStatus(orderId, newStatus) {
    /*
     * REAL BACKEND STEP:
     * // API ENDPOINT: PATCH /api/v1/orders/:id/status
     * fetch(`/api/v1/orders/${orderId}/status`, {
     *     method: 'PATCH',
     *     headers: { 'Content-Type': 'application/json' },
     *     body: JSON.stringify({ status: newStatus })
     * });
     */
    const order = mockOrders.find(o => o.id === orderId);
    if (!order) return;

    order.status = newStatus;

    // Update badge in place without full re-render
    const badgeKey = orderId.replace(/-/g, '_');
    const badge = document.getElementById(`status-badge-${badgeKey}`);
    if (badge) {
        badge.className = `badge ${STATUS_BADGE[newStatus]}`;
        badge.textContent = newStatus;
    }

    showToast(`Booking ${orderId} status changed to "${newStatus}"`, 'success');
}
