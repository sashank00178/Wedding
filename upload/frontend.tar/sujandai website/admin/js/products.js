/**
 * ====================================================================
 * WEDDING MOMENT NEPAL - PRODUCTS/PACKAGES CONTROLLER (products.js)
 * ====================================================================
 */

// Mock Photography Packages
let mockProducts = [
    {
        id: 1,
        name: 'Royal Wedding Package',
        category: 'Full Wedding',
        price: 180000,
        description: 'Complete wedding day coverage including ceremony, reception, and rituals. 600+ edited photos + cinematic teaser.',
        status: 'Active',
        image: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=600&auto=format&fit=crop&q=80'
    },
    {
        id: 2,
        name: 'Pre-Wedding Outdoor Shoot',
        category: 'Pre-Wedding',
        price: 45000,
        description: 'Romantic outdoor pre-wedding photoshoot at a location of your choice. 150+ edited photos.',
        status: 'Active',
        image: 'https://images.unsplash.com/photo-1537633552985-df8429e8048b?w=600&auto=format&fit=crop&q=80'
    },
    {
        id: 3,
        name: 'Cinematic Wedding Film',
        category: 'Videography',
        price: 120000,
        description: 'Cinematic 5–8 minute highlight film with drone footage, slow motion, and custom music.',
        status: 'Active',
        image: 'https://images.unsplash.com/photo-1606800052052-a08af7148866?w=600&auto=format&fit=crop&q=80'
    },
    {
        id: 4,
        name: 'Engagement & Reception',
        category: 'Events',
        price: 65000,
        description: 'Full-day engagement ceremony plus reception coverage. 300+ edited photos and a short highlights video.',
        status: 'Active',
        image: 'https://images.unsplash.com/photo-1591604466107-ec97de577aff?w=600&auto=format&fit=crop&q=80'
    },
    {
        id: 5,
        name: 'Studio Portrait Session',
        category: 'Portrait',
        price: 15000,
        description: 'Professional in-studio portrait session with professional lighting. 50+ edited high-res photos.',
        status: 'Active',
        image: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=600&auto=format&fit=crop&q=80'
    },
    {
        id: 6,
        name: 'Destination Wedding Nepal',
        category: 'Full Wedding',
        price: 350000,
        description: 'Two-day destination wedding photography across the scenic Himalayan landscapes of Nepal.',
        status: 'Inactive',
        image: 'https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?w=600&auto=format&fit=crop&q=80'
    }
];

let editingProductId = null;
let selectedImageDataUrl = null;

document.addEventListener('DOMContentLoaded', () => {
    renderSharedLayout('Package Management');

    /*
     * REAL BACKEND STEP:
     * // API ENDPOINT: GET /api/v1/products
     * fetch('/api/v1/products')
     *   .then(res => res.json())
     *   .then(data => { mockProducts = data; renderProducts(); });
     */

    document.getElementById('pkg-search')?.addEventListener('input', renderProducts);
    document.getElementById('pkg-category-filter')?.addEventListener('change', renderProducts);
    document.getElementById('pkg-status-filter')?.addEventListener('change', renderProducts);

    // Image upload preview
    document.getElementById('pkg-image-input')?.addEventListener('change', handleImagePreview);

    renderProducts();
});

function renderProducts() {
    const grid = document.getElementById('products-grid');
    const countEl = document.getElementById('pkg-count');
    if (!grid) return;

    const search = document.getElementById('pkg-search')?.value.toLowerCase().trim() || '';
    const category = document.getElementById('pkg-category-filter')?.value || 'all';
    const status = document.getElementById('pkg-status-filter')?.value || 'all';

    let filtered = mockProducts.filter(p => {
        const matchSearch = p.name.toLowerCase().includes(search) || p.description.toLowerCase().includes(search);
        const matchCat = category === 'all' || p.category === category;
        const matchStatus = status === 'all' || p.status === status;
        return matchSearch && matchCat && matchStatus;
    });

    if (countEl) countEl.textContent = `Showing ${filtered.length} of ${mockProducts.length} Packages`;

    if (filtered.length === 0) {
        grid.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 3rem; color: var(--text-muted);">
                <i class="fa-solid fa-box-open" style="font-size: 2.5rem; display: block; margin-bottom: 1rem; color: var(--border-color-light);"></i>
                <p>No packages found. Try adjusting your search or filters.</p>
            </div>`;
        return;
    }

    grid.innerHTML = filtered.map(p => `
        <div class="package-card">
            <div class="package-image-wrap">
                <img src="${p.image}" alt="${escapeHtml(p.name)}" class="package-image" onerror="this.src='https://images.unsplash.com/photo-1519741497674-611481863552?w=600&auto=format&fit=crop&q=80'">
                <div class="package-badge-wrap">
                    <span class="badge ${p.status === 'Active' ? 'badge-success' : 'badge-danger'}">${p.status}</span>
                </div>
            </div>
            <div class="package-content">
                <span class="package-category">${escapeHtml(p.category)}</span>
                <h3 class="package-title">${escapeHtml(p.name)}</h3>
                <p class="package-description">${escapeHtml(p.description)}</p>
                <div class="package-footer">
                    <span class="package-price">Rs. ${p.price.toLocaleString('ne-NP')}</span>
                    <div style="display: flex; gap: 0.5rem;">
                        <button class="btn btn-secondary btn-sm" onclick="openEditProductModal(${p.id})" title="Edit">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="deleteProduct(${p.id})" title="Delete">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

function handleImagePreview(e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
        selectedImageDataUrl = ev.target.result;
        const preview = document.getElementById('image-preview-img');
        const placeholder = document.getElementById('image-preview-placeholder');
        if (preview) {
            preview.src = selectedImageDataUrl;
            preview.style.display = 'block';
        }
        if (placeholder) placeholder.style.display = 'none';
    };
    reader.readAsDataURL(file);
}

function openAddProductModal() {
    editingProductId = null;
    selectedImageDataUrl = null;
    document.getElementById('pkg-modal-title').textContent = 'Add New Photography Package';
    document.getElementById('pkg-form').reset();
    resetImagePreview();
    document.getElementById('pkg-modal-overlay').classList.add('active');
}

function openEditProductModal(id) {
    const product = mockProducts.find(p => p.id === id);
    if (!product) return;

    editingProductId = id;
    selectedImageDataUrl = product.image;
    document.getElementById('pkg-modal-title').textContent = `Edit: ${product.name}`;

    document.getElementById('pkg-name-input').value = product.name;
    document.getElementById('pkg-category-select').value = product.category;
    document.getElementById('pkg-price-input').value = product.price;
    document.getElementById('pkg-description-input').value = product.description;
    document.getElementById('pkg-status-select').value = product.status;

    const preview = document.getElementById('image-preview-img');
    const placeholder = document.getElementById('image-preview-placeholder');
    if (preview) { preview.src = product.image; preview.style.display = 'block'; }
    if (placeholder) placeholder.style.display = 'none';

    document.getElementById('pkg-modal-overlay').classList.add('active');
}

function resetImagePreview() {
    const preview = document.getElementById('image-preview-img');
    const placeholder = document.getElementById('image-preview-placeholder');
    if (preview) { preview.src = ''; preview.style.display = 'none'; }
    if (placeholder) placeholder.style.display = 'flex';
}

function closeProductModal() {
    document.getElementById('pkg-modal-overlay').classList.remove('active');
}

function saveProduct(e) {
    e.preventDefault();

    const name = document.getElementById('pkg-name-input').value.trim();
    const category = document.getElementById('pkg-category-select').value;
    const price = parseFloat(document.getElementById('pkg-price-input').value);
    const description = document.getElementById('pkg-description-input').value.trim();
    const status = document.getElementById('pkg-status-select').value;

    if (!name || !price) {
        showToast('Please fill in all required fields.', 'danger');
        return;
    }

    const finalImage = selectedImageDataUrl || 'https://images.unsplash.com/photo-1519741497674-611481863552?w=600&auto=format&fit=crop&q=80';

    if (editingProductId) {
        /*
         * REAL BACKEND STEP:
         * // API ENDPOINT: PUT /api/v1/products/:id
         * const formData = new FormData(document.getElementById('pkg-form'));
         * fetch(`/api/v1/products/${editingProductId}`, { method: 'PUT', body: formData });
         */
        const idx = mockProducts.findIndex(p => p.id === editingProductId);
        if (idx !== -1) {
            mockProducts[idx] = { ...mockProducts[idx], name, category, price, description, status, image: finalImage };
            showToast(`Package "${name}" updated!`, 'success');
        }
    } else {
        /*
         * REAL BACKEND STEP:
         * // API ENDPOINT: POST /api/v1/products
         * const formData = new FormData(document.getElementById('pkg-form'));
         * fetch('/api/v1/products', { method: 'POST', body: formData });
         */
        const newId = mockProducts.length > 0 ? Math.max(...mockProducts.map(p => p.id)) + 1 : 1;
        mockProducts.unshift({ id: newId, name, category, price, description, status, image: finalImage });
        showToast(`Package "${name}" added!`, 'success');
    }

    closeProductModal();
    renderProducts();
}

function deleteProduct(id) {
    const product = mockProducts.find(p => p.id === id);
    if (!product) return;

    if (confirm(`Delete package "${product.name}"? This cannot be undone.`)) {
        /*
         * REAL BACKEND STEP:
         * // API ENDPOINT: DELETE /api/v1/products/:id
         * fetch(`/api/v1/products/${id}`, { method: 'DELETE' });
         */
        mockProducts = mockProducts.filter(p => p.id !== id);
        showToast(`Package "${product.name}" deleted.`, 'danger');
        renderProducts();
    }
}
