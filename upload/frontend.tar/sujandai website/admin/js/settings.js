/**
 * ====================================================================
 * WEDDING MOMENT NEPAL - SETTINGS CONTROLLER (settings.js)
 * ====================================================================
 */

// Mock Settings State
let settings = {
    businessName: 'Wedding Moment Nepal',
    contactEmail: 'info@weddingmoment.np',
    phone: '+977-9841234567',
    address: 'Lalitpur, Kathmandu, Nepal',
    facebook: 'https://facebook.com/weddingmomentnepal',
    instagram: 'https://instagram.com/weddingmoment_np',
    youtube: 'https://youtube.com/@weddingmomentnepal',
    onlineBooking: true,
    maintenanceMode: false,
    emailNotifications: true,
    smsNotifications: false
};

document.addEventListener('DOMContentLoaded', () => {
    renderSharedLayout('Settings');

    /*
     * REAL BACKEND STEP:
     * // API ENDPOINT: GET /api/v1/settings
     * fetch('/api/v1/settings').then(r => r.json()).then(data => { settings = data; loadSettings(); });
     */

    loadSettings();

    document.getElementById('settings-form')?.addEventListener('submit', saveSettings);
});

function loadSettings() {
    // Populate form fields from settings object
    setValue('biz-name', settings.businessName);
    setValue('contact-email', settings.contactEmail);
    setValue('phone', settings.phone);
    setValue('address', settings.address);
    setValue('facebook', settings.facebook);
    setValue('instagram', settings.instagram);
    setValue('youtube', settings.youtube);

    // Set toggles
    setToggle('toggle-booking', settings.onlineBooking);
    setToggle('toggle-maintenance', settings.maintenanceMode);
    setToggle('toggle-email-notif', settings.emailNotifications);
    setToggle('toggle-sms-notif', settings.smsNotifications);
}

function setValue(id, val) {
    const el = document.getElementById(id);
    if (el) el.value = val || '';
}

function setToggle(id, state) {
    const el = document.getElementById(id);
    if (el) {
        el.checked = state;
        updateToggleLabel(id, state);
    }
}

function toggleSwitch(id) {
    const el = document.getElementById(id);
    if (!el) return;
    updateToggleLabel(id, el.checked);
}

function updateToggleLabel(id, state) {
    const label = document.getElementById(`${id}-label`);
    if (label) {
        label.textContent = state ? 'Enabled' : 'Disabled';
        label.style.color = state ? 'var(--success)' : 'var(--text-muted)';
    }
}

function saveSettings(e) {
    e.preventDefault();

    settings.businessName = document.getElementById('biz-name')?.value.trim() || settings.businessName;
    settings.contactEmail = document.getElementById('contact-email')?.value.trim() || settings.contactEmail;
    settings.phone = document.getElementById('phone')?.value.trim() || settings.phone;
    settings.address = document.getElementById('address')?.value.trim() || settings.address;
    settings.facebook = document.getElementById('facebook')?.value.trim() || settings.facebook;
    settings.instagram = document.getElementById('instagram')?.value.trim() || settings.instagram;
    settings.youtube = document.getElementById('youtube')?.value.trim() || settings.youtube;
    settings.onlineBooking = document.getElementById('toggle-booking')?.checked;
    settings.maintenanceMode = document.getElementById('toggle-maintenance')?.checked;
    settings.emailNotifications = document.getElementById('toggle-email-notif')?.checked;
    settings.smsNotifications = document.getElementById('toggle-sms-notif')?.checked;

    /*
     * REAL BACKEND STEP:
     * // API ENDPOINT: PUT /api/v1/settings
     * fetch('/api/v1/settings', {
     *     method: 'PUT',
     *     headers: { 'Content-Type': 'application/json' },
     *     body: JSON.stringify(settings)
     * });
     */

    showToast('Settings saved successfully!', 'success');
}
