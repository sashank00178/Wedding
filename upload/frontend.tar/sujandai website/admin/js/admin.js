/**
 * ====================================================================
 * WEDDING MOMENT NEPAL - SHARED ADMIN MODULE (admin.js)
 * ====================================================================
 * Functions:
 * 1. Auth Guard (checkAuth)
 * 2. Shared Layout Injection (Sidebar & Topbar)
 * 3. Mobile Navigation Drawer Toggle
 * 4. Active Page Highlight
 * 5. Logout Handling
 * 6. UI Helpers (Toast notifications)
 * ====================================================================
 */

// Storage Key constant
const AUTH_STORAGE_KEY = 'wedding_admin_session';

/**
 * Check if the user is authenticated.
 * @param {boolean} requireAuth - If true, redirect unauthenticated users to login.html
 */
function checkAuth(requireAuth = true) {
    /* 
     * Real Backend API Integration Note:
     * Currently using client-side localStorage to simulate session state.
     * -------------------------------------------------------------------
     * REAL BACKEND STEP:
     * Replace this check with a request to verify the HTTP-Only JWT Cookie:
     * // API ENDPOINT: GET /api/v1/auth/me
     * fetch('/api/v1/auth/me', { credentials: 'include' })
     *   .then(res => res.json())
     *   .catch(() => window.location.href = 'login.html');
     */

    const sessionData = localStorage.getItem(AUTH_STORAGE_KEY);
    const isLoggedIn = !!sessionData;

    const currentPage = window.location.pathname.split('/').pop();

    if (requireAuth && !isLoggedIn && currentPage !== 'login.html') {
        window.location.href = 'login.html';
        return null;
    }

    if (!requireAuth && isLoggedIn && currentPage === 'login.html') {
        window.location.href = 'dashboard.html';
        return null;
    }

    try {
        return sessionData ? JSON.parse(sessionData) : null;
    } catch (e) {
        localStorage.removeItem(AUTH_STORAGE_KEY);
        if (requireAuth) window.location.href = 'login.html';
        return null;
    }
}

/**
 * Render shared Sidebar and Topbar into the placeholder DOM elements.
 * @param {string} activePageTitle - Title of the current active page
 */
function renderSharedLayout(activePageTitle = 'Dashboard') {
    const user = checkAuth(true);
    if (!user) return; // Exit if redirected to login

    const currentPage = window.location.pathname.split('/').pop() || 'dashboard.html';

    // Inject Sidebar
    const sidebarContainer = document.getElementById('admin-sidebar');
    if (sidebarContainer) {
        sidebarContainer.innerHTML = `
            <aside class="sidebar" id="sidebar">
                <div class="sidebar-header">
                    <a href="dashboard.html" class="sidebar-logo">
                        <i class="fa-solid fa-camera-retro"></i>
                        Wedding <span>Moment</span>
                    </a>
                </div>
                
                <ul class="sidebar-menu">
                    <li class="menu-category">Main Menu</li>
                    
                    <li class="menu-item">
                        <a href="dashboard.html" class="menu-link ${currentPage === 'dashboard.html' ? 'active' : ''}">
                            <i class="fa-solid fa-chart-line"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>

                    <li class="menu-item">
                        <a href="orders.html" class="menu-link ${currentPage === 'orders.html' ? 'active' : ''}">
                            <i class="fa-solid fa-calendar-check"></i>
                            <span>Bookings / Orders</span>
                        </a>
                    </li>

                    <li class="menu-item">
                        <a href="products.html" class="menu-link ${currentPage === 'products.html' ? 'active' : ''}">
                            <i class="fa-solid fa-box-open"></i>
                            <span>Packages</span>
                        </a>
                    </li>

                    <li class="menu-item">
                        <a href="users.html" class="menu-link ${currentPage === 'users.html' ? 'active' : ''}">
                            <i class="fa-solid fa-users"></i>
                            <span>Users</span>
                        </a>
                    </li>

                    <li class="menu-category">System</li>

                    <li class="menu-item">
                        <a href="profile.html" class="menu-link ${currentPage === 'profile.html' ? 'active' : ''}">
                            <i class="fa-solid fa-user-gear"></i>
                            <span>My Profile</span>
                        </a>
                    </li>

                    <li class="menu-item">
                        <a href="settings.html" class="menu-link ${currentPage === 'settings.html' ? 'active' : ''}">
                            <i class="fa-solid fa-sliders"></i>
                            <span>Settings</span>
                        </a>
                    </li>

                    <li class="menu-item" style="margin-top: 1.5rem;">
                        <a href="../sujanfrontend.html" target="_blank" class="menu-link">
                            <i class="fa-solid fa-globe"></i>
                            <span>View Public Site</span>
                        </a>
                    </li>
                </ul>

                <div class="sidebar-footer">
                    <p>&copy; ${new Date().getFullYear()} Wedding Moment Nepal</p>
                </div>
            </aside>
            <div class="sidebar-overlay" id="sidebar-overlay"></div>
        `;
    }

    // Inject Top Navigation
    const headerContainer = document.getElementById('admin-header');
    if (headerContainer) {
        headerContainer.innerHTML = `
            <header class="topbar">
                <div class="topbar-left">
                    <button class="mobile-toggle" id="mobile-toggle" aria-label="Toggle Navigation">
                        <i class="fa-solid fa-bars"></i>
                    </button>
                    <h1 class="page-title">${activePageTitle}</h1>
                </div>

                <div class="topbar-right">
                    <button class="notification-btn" title="Notifications" onclick="showToast('No new notifications', 'info')">
                        <i class="fa-solid fa-bell"></i>
                        <span class="notification-badge">3</span>
                    </button>

                    <div class="user-profile-menu">
                        <img src="${user.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80'}" alt="Avatar" class="user-avatar">
                        <div class="user-details">
                            <span class="user-name">${escapeHtml(user.name || user.username || 'Admin')}</span>
                            <span class="user-role">${escapeHtml(user.role || 'Administrator')}</span>
                        </div>
                    </div>

                    <button class="btn-logout" id="logout-btn" onclick="logout()">
                        <i class="fa-solid fa-right-from-bracket"></i>
                        <span>Logout</span>
                    </button>
                </div>
            </header>
        `;
    }

    // Attach Mobile Navigation Listeners
    initMobileNav();
}

/**
 * Mobile Navigation Drawer Toggle Handler
 */
function initMobileNav() {
    const toggleBtn = document.getElementById('mobile-toggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');

    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('mobile-open');
            if (overlay) overlay.classList.toggle('active');
        });
    }

    if (overlay) {
        overlay.addEventListener('click', () => {
            if (sidebar) sidebar.classList.remove('mobile-open');
            overlay.classList.remove('active');
        });
    }
}

/**
 * Clear session and log out user.
 */
function logout() {
    /* 
     * Real Backend API Integration Note:
     * // API ENDPOINT: POST /api/v1/auth/logout
     * fetch('/api/v1/auth/logout', { method: 'POST' })
     *   .finally(() => {
     *       localStorage.removeItem(AUTH_STORAGE_KEY);
     *       window.location.href = 'login.html';
     *   });
     */

    localStorage.removeItem(AUTH_STORAGE_KEY);
    showToast('Logged out successfully', 'success');
    setTimeout(() => {
        window.location.href = 'login.html';
    }, 500);
}

/**
 * Toast Notification Helper
 */
function showToast(message, type = 'info') {
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <i class="fa-solid ${type === 'success' ? 'fa-circle-check' : type === 'danger' ? 'fa-circle-xmark' : 'fa-circle-info'}"></i>
        <span>${escapeHtml(message)}</span>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

/**
 * Utility to escape HTML and prevent XSS
 */
function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}
