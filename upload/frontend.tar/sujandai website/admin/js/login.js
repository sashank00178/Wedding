/**
 * ====================================================================
 * WEDDING MOMENT NEPAL - LOGIN CONTROLLER (login.js)
 * ====================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Check if user is already logged in, redirect to dashboard if so
    checkAuth(false);

    const loginForm = document.getElementById('login-form');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const loginAlert = document.getElementById('login-alert');
    const alertMessage = document.getElementById('alert-message');
    const togglePasswordBtn = document.getElementById('toggle-password');

    // Toggle Password Visibility
    if (togglePasswordBtn && passwordInput) {
        togglePasswordBtn.addEventListener('click', () => {
            const isPassword = passwordInput.type === 'password';
            passwordInput.type = isPassword ? 'text' : 'password';
            togglePasswordBtn.classList.toggle('fa-eye');
            togglePasswordBtn.classList.toggle('fa-eye-slash');
        });
    }

    // Login Form Submission
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const username = usernameInput.value.trim();
            const password = passwordInput.value.trim();

            // Client-side Basic Validation
            if (!username || !password) {
                showError('Please enter both username and password.');
                return;
            }

            /*
             * =================================================================
             * MOCK AUTHENTICATION CHECK
             * =================================================================
             * NOTE FOR BACKEND DEVELOPER / GOING LIVE:
             * This hardcoded check ('admin' / 'admin123') is NOT secure and is
             * ONLY for frontend mock testing. 
             * 
             * REPLACE WITH REAL BACKEND CALL:
             * // API ENDPOINT: POST /api/v1/auth/login
             * fetch('/api/v1/auth/login', {
             *     method: 'POST',
             *     headers: { 'Content-Type': 'application/json' },
             *     body: JSON.stringify({ username, password })
             * })
             * .then(res => res.json())
             * .then(data => {
             *     // Store auth token in HTTP-only cookie or secure storage
             * });
             * =================================================================
             */

            if (username === 'admin' && password === 'admin123') {
                hideError();

                // Mock Admin User Session Payload
                const mockUserData = {
                    id: 1,
                    username: 'admin',
                    name: 'Sujan Shrestha',
                    email: 'admin@weddingmoment.np',
                    role: 'Super Admin',
                    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
                    loggedInAt: new Date().toISOString()
                };

                /*
                 * STORAGE CHOICE: localStorage vs sessionStorage
                 * -------------------------------------------------------------
                 * sessionStorage: Cleared automatically when browser tab closes.
                 * localStorage:   Persists across tab reopens until explicit logout.
                 * 
                 * We are using localStorage below so you stay logged in during 
                 * active development/testing across multiple tabs.
                 */
                localStorage.setItem('wedding_admin_session', JSON.stringify(mockUserData));

                showToast('Login successful! Redirecting...', 'success');

                // Redirect to dashboard after brief delay for smooth UX feedback
                setTimeout(() => {
                    window.location.href = 'dashboard.html';
                }, 800);

            } else {
                showError('Invalid username or password. Try admin / admin123');
            }
        });
    }

    function showError(msg) {
        if (loginAlert && alertMessage) {
            alertMessage.textContent = msg;
            loginAlert.style.display = 'flex';
        }
    }

    function hideError() {
        if (loginAlert) {
            loginAlert.style.display = 'none';
        }
    }
});
