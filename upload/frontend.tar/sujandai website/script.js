/**
 * ==============================================================================
 * WEDDING PHOTOGRAPHY WEBSITE FRONTEND SCRIPT (script.js)
 * ==============================================================================
 * Connects the frontend UI to our Node.js + Express backend server & gallery.
 */

// BACKEND API URL
const BACKEND_URL = 'http://localhost:5000';

document.addEventListener('DOMContentLoaded', () => {

    // 1. Header scroll effect
    const header = document.getElementById('header');
    if (header) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 100) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }

    // 2. Mobile menu toggle
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const navLinks = document.getElementById('navLinks');
    if (mobileMenuBtn && navLinks) {
        mobileMenuBtn.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            mobileMenuBtn.innerHTML = navLinks.classList.contains('active') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });

        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                navLinks.classList.remove('active');
                mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            });
        });
    }

    // 3. Complete Gallery Items (Local HD Images + Fallbacks)
    const galleryGrid = document.getElementById('galleryGrid');
    const filterBtns = document.querySelectorAll('.filter-btn');

    const galleryItems = [
        { id: 1, category: 'wedding', src: 'images/wedding1.jpg', fallback: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1000&q=80', alt: 'Nepali Wedding Photography' },
        { id: 2, category: 'portrait', src: 'images/portrait1.jpg', fallback: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?auto=format&fit=crop&w=1000&q=80', alt: 'Studio Portrait Photography' },
        { id: 3, category: 'commercial', src: 'images/commercial1.jpg', fallback: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1000&q=80', alt: 'Commercial Product Photography' },
        { id: 4, category: 'event', src: 'images/event1.jpg', fallback: 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1000&q=80', alt: 'Celebration Event Photography' },
        { id: 5, category: 'wedding', src: 'https://images.unsplash.com/photo-1465495976277-4387d4b0e4a6?auto=format&fit=crop&w=1000&q=80', fallback: 'images/wedding1.jpg', alt: 'Romantic Wedding Moment' },
        { id: 6, category: 'portrait', src: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1000&q=80', fallback: 'images/portrait1.jpg', alt: 'Creative Portrait Photography' },
        { id: 7, category: 'commercial', src: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=1000&q=80', fallback: 'images/commercial1.jpg', alt: 'Business Commercial Photography' },
        { id: 8, category: 'event', src: 'https://images.unsplash.com/photo-1492684223066-dd23140edf6d?auto=format&fit=crop&w=1000&q=80', fallback: 'images/event1.jpg', alt: 'Concert & Party Photography' },
        { id: 9, category: 'portrait', src: 'https://images.unsplash.com/photo-1488161628813-04466f872be2?auto=format&fit=crop&w=1000&q=80', fallback: 'images/portrait1.jpg', alt: 'Outdoor Portrait Shoot' }
    ];

    function renderGalleryItems(filter = 'all') {
        if (!galleryGrid) return;
        galleryGrid.innerHTML = '';
        const filteredItems = filter === 'all' ? galleryItems : galleryItems.filter(item => item.category === filter);
        
        filteredItems.forEach(item => {
            const galleryItem = document.createElement('div');
            galleryItem.className = 'gallery-item';
            galleryItem.innerHTML = `
                <img src="${item.src}" alt="${item.alt}" onerror="this.onerror=null; this.src='${item.fallback}';">
                <div class="gallery-item-overlay">
                    <i class="fas fa-search-plus fa-2x" style="color: white;"></i>
                </div>
            `;
            galleryGrid.appendChild(galleryItem);
        });
    }

    if (galleryGrid) {
        renderGalleryItems();
        filterBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                filterBtns.forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                renderGalleryItems(this.getAttribute('data-filter'));
            });
        });
    }

    // 4. Booking Form -> Sync with Payment Form
    const bookingForm = document.getElementById('bookingForm');
    if (bookingForm) {
        bookingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('name').value;
            const phone = document.getElementById('phone').value;
            const service = document.getElementById('service').value;

            // Pre-fill Payment Form
            const paymentName = document.getElementById('paymentName');
            const paymentPhone = document.getElementById('paymentPhone');
            const paymentPackage = document.getElementById('paymentPackage');
            const paymentAmountInput = document.getElementById('paymentAmount');
            const payBtn = document.getElementById('payButton');

            if (paymentName) paymentName.value = name;
            if (paymentPhone) paymentPhone.value = phone;

            if (paymentPackage && service) {
                for (let option of paymentPackage.options) {
                    if (option.value.toLowerCase().includes(service.toLowerCase())) {
                        option.selected = true;
                        const amt = option.getAttribute('data-amount');
                        if (paymentAmountInput) paymentAmountInput.value = amt;
                        const gateway = document.getElementById('selectedGateway') ? document.getElementById('selectedGateway').value : 'esewa';
                        if (payBtn) {
                            const icon = gateway === 'esewa' ? 'fa-wallet' : 'fa-mobile-alt';
                            payBtn.innerHTML = `<i class="fas ${icon}"></i> Pay Rs. ${amt} with ${gateway === 'esewa' ? 'eSewa' : 'Khalti'}`;
                        }
                        break;
                    }
                }
            }

            // Scroll to payment section smoothly
            const paymentSec = document.getElementById('payment');
            if (paymentSec) {
                paymentSec.scrollIntoView({ behavior: 'smooth' });
            }
        });
    }

    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('contactName').value;
            alert(`Thank you ${name}! Your message has been sent. We'll get back to you soon.`);
            contactForm.reset();
        });
    }

    // Set min date for booking to today
    const dateInput = document.getElementById('date');
    if (dateInput) {
        const today = new Date().toISOString().split('T')[0];
        dateInput.setAttribute('min', today);
    }

    // ==========================================================================
    // 5. REAL eSEWA AND KHALTI PAYMENT SYSTEM (CALLS BACKEND SERVER)
    // ==========================================================================
    const paymentMethods = document.querySelectorAll('.payment-method');
    const selectedGatewayInput = document.getElementById('selectedGateway');
    const paymentPackageSelect = document.getElementById('paymentPackage');
    const paymentAmountInput = document.getElementById('paymentAmount');
    const payBtn = document.getElementById('payButton');
    const paymentForm = document.getElementById('realPaymentForm');
    const paymentStatusDiv = document.getElementById('paymentStatus');

    if (paymentMethods.length > 0) {
        paymentMethods.forEach(method => {
            method.addEventListener('click', function() {
                paymentMethods.forEach(m => {
                    m.classList.remove('active');
                    m.style.borderColor = '#ccc';
                    m.style.backgroundColor = '#f9f9f9';
                });
                this.classList.add('active');
                
                const selectedMethod = this.getAttribute('data-method');
                if (selectedGatewayInput) selectedGatewayInput.value = selectedMethod;

                if (selectedMethod === 'esewa') {
                    this.style.borderColor = '#60bb46';
                    this.style.backgroundColor = '#f0fff0';
                    if (payBtn) {
                        payBtn.style.backgroundColor = '#60bb46';
                        payBtn.style.borderColor = '#60bb46';
                        payBtn.innerHTML = `<i class="fas fa-wallet"></i> Pay Rs. ${paymentAmountInput.value} with eSewa`;
                    }
                } else if (selectedMethod === 'khalti') {
                    this.style.borderColor = '#5c2d91';
                    this.style.backgroundColor = '#f8f4ff';
                    if (payBtn) {
                        payBtn.style.backgroundColor = '#5c2d91';
                        payBtn.style.borderColor = '#5c2d91';
                        payBtn.innerHTML = `<i class="fas fa-mobile-alt"></i> Pay Rs. ${paymentAmountInput.value} with Khalti`;
                    }
                }
            });
        });
    }

    if (paymentPackageSelect && paymentAmountInput) {
        paymentPackageSelect.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const amount = selectedOption.getAttribute('data-amount');
            paymentAmountInput.value = amount;

            const gateway = selectedGatewayInput ? selectedGatewayInput.value : 'esewa';
            if (payBtn) {
                if (gateway === 'esewa') {
                    payBtn.innerHTML = `<i class="fas fa-wallet"></i> Pay Rs. ${amount} with eSewa`;
                } else {
                    payBtn.innerHTML = `<i class="fas fa-mobile-alt"></i> Pay Rs. ${amount} with Khalti`;
                }
            }
        });
    }

    if (paymentForm) {
        paymentForm.addEventListener('submit', async function(e) {
            e.preventDefault();

            const gateway = selectedGatewayInput.value;
            const amount = paymentAmountInput.value;
            const customerName = document.getElementById('paymentName').value;
            const customerPhone = document.getElementById('paymentPhone').value;
            const customerEmail = 'customer@weddingmoment.np';
            const packageName = paymentPackageSelect.options[paymentPackageSelect.selectedIndex].value;

            if (payBtn) {
                payBtn.disabled = true;
                payBtn.innerHTML = `<i class="fas fa-spinner fa-spin"></i> Connecting to ${gateway.toUpperCase()} Backend...`;
            }
            if (paymentStatusDiv) {
                paymentStatusDiv.style.display = 'block';
                paymentStatusDiv.style.backgroundColor = '#e8f4fd';
                paymentStatusDiv.style.color = '#1e549f';
                paymentStatusDiv.style.border = '1px solid #bce0fd';
                paymentStatusDiv.innerHTML = `⏳ Generating secure transaction token from Node.js backend...`;
            }

            try {
                if (gateway === 'esewa') {
                    const response = await fetch(`${BACKEND_URL}/api/esewa/initiate`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            amount: amount,
                            productName: packageName,
                            customerName: customerName
                        })
                    });

                    const data = await response.json();

                    if (!data.success) {
                        throw new Error(data.message || 'Failed to initiate eSewa payment');
                    }

                    if (paymentStatusDiv) {
                        paymentStatusDiv.innerHTML = `✅ Signature verified! Redirecting to eSewa Portal...`;
                    }

                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = data.payment_url;

                    Object.keys(data.formData).forEach(key => {
                        const input = document.createElement('input');
                        input.type = 'hidden';
                        input.name = key;
                        input.value = data.formData[key];
                        form.appendChild(input);
                    });

                    document.body.appendChild(form);
                    form.submit();

                } else if (gateway === 'khalti') {
                    const response = await fetch(`${BACKEND_URL}/api/khalti/initiate`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            amount: amount,
                            purchase_order_id: `order-${Date.now()}`,
                            purchase_order_name: packageName,
                            customer_info: {
                                name: customerName,
                                email: customerEmail,
                                phone: customerPhone
                            }
                        })
                    });

                    const data = await response.json();

                    if (!data.success || !data.payment_url) {
                        throw new Error(data.message || 'Failed to get Khalti payment URL');
                    }

                    if (paymentStatusDiv) {
                        paymentStatusDiv.innerHTML = `✅ Khalti Payment Token Created! Redirecting...`;
                    }

                    window.location.href = data.payment_url;
                }

            } catch (error) {
                console.error('[Payment Error]:', error);
                if (payBtn) {
                    payBtn.disabled = false;
                    payBtn.innerHTML = `Try Again`;
                }
                if (paymentStatusDiv) {
                    paymentStatusDiv.style.backgroundColor = '#fde8e8';
                    paymentStatusDiv.style.color = '#9f1e1e';
                    paymentStatusDiv.style.border = '1px solid #f8b4b4';
                    paymentStatusDiv.innerHTML = `❌ Connection Error: ${error.message}. Make sure your Node.js server is running at ${BACKEND_URL}!`;
                }
            }
        });
    }

    // 6. CHECK FOR PAYMENT RETURN RESULTS IN URL QUERY PARAMS
    const urlParams = new URLSearchParams(window.location.search);
    const paymentResult = urlParams.get('payment');
    const gatewayUsed = urlParams.get('gateway');
    const refCode = urlParams.get('ref');
    const paidAmount = urlParams.get('amount');

    if (paymentResult === 'success') {
        showPaymentReceiptModal({
            gateway: gatewayUsed ? gatewayUsed.toUpperCase() : 'ONLINE',
            ref: refCode || 'N/A',
            amount: paidAmount || 'N/A'
        });
        window.history.replaceState({}, document.title, window.location.pathname);
    } else if (paymentResult === 'failed' || paymentResult === 'cancelled') {
        alert(`⚠️ Payment ${paymentResult}. Please try again or contact our studio at +977 9856010315.`);
        window.history.replaceState({}, document.title, window.location.pathname);
    }

    function showPaymentReceiptModal(details) {
        const modal = document.createElement('div');
        modal.style.position = 'fixed';
        modal.style.top = '0';
        modal.style.left = '0';
        modal.style.width = '100%';
        modal.style.height = '100%';
        modal.style.backgroundColor = 'rgba(0,0,0,0.7)';
        modal.style.zIndex = '9999';
        modal.style.display = 'flex';
        modal.style.alignItems = 'center';
        modal.style.justifyContent = 'center';
        modal.style.padding = '20px';

        modal.innerHTML = `
            <div style="background: #ffffff; padding: 35px; border-radius: 12px; max-width: 450px; width: 100%; text-align: center; box-shadow: 0 10px 30px rgba(0,0,0,0.3); position: relative;">
                <div style="width: 70px; height: 70px; background: #e6f9ed; color: #27ae60; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 32px;">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h2 style="font-family: 'Playfair Display', serif; margin-bottom: 10px; color: #222;">Payment Confirmed!</h2>
                <p style="color: #666; margin-bottom: 25px; font-size: 0.95rem;">Your photography booking is successfully confirmed with Wedding Moment Nepal.</p>
                
                <div style="background: #f8f9fa; border-radius: 8px; padding: 20px; text-align: left; margin-bottom: 25px; font-size: 0.9rem;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                        <span style="color: #777;">Payment Gateway:</span>
                        <strong style="color: #333;">${details.gateway}</strong>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                        <span style="color: #777;">Transaction Ref:</span>
                        <strong style="color: #333;">${details.ref}</strong>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #777;">Amount Paid:</span>
                        <strong style="color: #27ae60; font-size: 1.05rem;">Rs. ${details.amount}</strong>
                    </div>
                </div>

                <button id="closeModalBtn" class="btn" style="width: 100%; background: #d4af37; border-color: #d4af37; color: #000; font-weight: 600; padding: 12px;">Done & Close</button>
            </div>
        `;

        document.body.appendChild(modal);

        document.getElementById('closeModalBtn').addEventListener('click', () => {
            modal.remove();
        });
    }
});
