/**
 * ==============================================================================
 * WEDDING PHOTOGRAPHY PAYMENT BACKEND (Node.js + Express)
 * ==============================================================================
 * 
 * Welcome! This backend server safely manages eSewa and Khalti payments.
 * 
 * WHY IS THIS BACKEND NEEDED?
 * 1. Security: Secret keys stay on this server in the .env file. The web browser
 *    (frontend) never sees your secret key.
 * 2. Verification: The backend checks directly with eSewa & Khalti to confirm 
 *    that real money was transferred before confirming a customer's booking.
 * 
 * ==============================================================================
 */

// 1. IMPORT REQUIRED LIBRARIES
const express = require('express');   // Web framework to handle HTTP requests
const cors = require('cors');         // Allows your frontend to make calls to this backend
const axios = require('axios');       // Library to make HTTP API requests to Khalti
const crypto = require('crypto');     // Node.js built-in library for HMAC security signatures
require('dotenv').config();           // Loads secret variables from your .env file

// 2. INITIALIZE EXPRESS APPLICATION
const app = express();
const PORT = process.env.PORT || 5000;

// Enable CORS so your frontend HTML/JS page can talk to this backend
app.use(cors());

// Parse JSON request bodies sent by frontend fetch calls
app.use(express.json());

// Parse URL-encoded data (useful for payment gateway redirects)
app.use(express.urlencoded({ extended: true }));

// Health Check Endpoint (to verify server is running)
app.get('/', (req, res) => {
    res.json({
        message: "Wedding Photography Payment Server is Running Smoothly! 📸✨",
        status: "Active"
    });
});

/**
 * ==============================================================================
 * SECTION 1: eSewa PAYMENT GATEWAY (v2 API)
 * ==============================================================================
 * 
 * eSewa v2 Payment Flow:
 * 1. Frontend sends payment amount to POST /api/esewa/initiate
 * 2. Backend signs payment details using HMAC-SHA256 and your ESEWA_SECRET_KEY
 * 3. Backend returns a form payload to frontend
 * 4. Frontend submits the form to eSewa's portal URL
 * 5. User pays on eSewa -> eSewa redirects to GET /api/esewa/success with base64 data
 * 6. Backend decodes base64 data & verifies signature to ensure valid payment
 */

// Endpoint 1: Initiate eSewa Payment
app.post('/api/esewa/initiate', (req, res) => {
    try {
        const { amount, productName, customerName } = req.body;

        if (!amount || amount <= 0) {
            return res.status(400).json({ success: false, message: 'Invalid payment amount' });
        }

        // Generate a unique Transaction UUID (e.g. req-1721893200000-482)
        const transaction_uuid = `order-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

        // Convert amount to string (eSewa requires exact string format like "14999" or "100.00")
        const total_amount = String(amount);
        const product_code = process.env.ESEWA_PRODUCT_CODE || 'EPAYTEST';

        // 1. Prepare message string for HMAC-SHA256 signature
        // Standard eSewa v2 signature format: total_amount,transaction_uuid,product_code
        const signatureString = `total_amount=${total_amount},transaction_uuid=${transaction_uuid},product_code=${product_code}`;

        // 2. Generate HMAC-SHA256 signature using your secret key stored securely in process.env.ESEWA_SECRET_KEY
        const hmac = crypto.createHmac('sha256', process.env.ESEWA_SECRET_KEY);
        hmac.update(signatureString);
        const signature = hmac.digest('base64'); // eSewa expects Base64 encoding

        // 3. Construct form payload to return to the frontend
        const formData = {
            amount: total_amount,
            tax_amount: "0",
            total_amount: total_amount,
            transaction_uuid: transaction_uuid,
            product_code: product_code,
            product_service_charge: "0",
            product_delivery_charge: "0",
            success_url: `${process.env.BACKEND_URL}/api/esewa/success`,
            failure_url: `${process.env.BACKEND_URL}/api/esewa/failure`,
            signed_field_names: "total_amount,transaction_uuid,product_code",
            signature: signature
        };

        console.log(`[eSewa] Initiated transaction ${transaction_uuid} for NPR ${total_amount}`);

        // Return form parameters and eSewa gateway URL to frontend
        return res.json({
            success: true,
            payment_url: process.env.ESEWA_PAYMENT_URL || "https://rc-epay.esewa.com.np/api/epay/main/v2/form",
            formData: formData
        });

    } catch (error) {
        console.error('[eSewa Error] Initiation failed:', error);
        return res.status(500).json({ success: false, message: 'Failed to initiate eSewa payment' });
    }
});

// Endpoint 2: eSewa Payment Success Callback (Verification)
app.get('/api/esewa/success', (req, res) => {
    try {
        // eSewa sends encoded payload as query parameter: ?data=BASE64_STRING
        const encodedData = req.query.data;

        if (!encodedData) {
            return res.status(400).send('Invalid eSewa response data');
        }

        // Decode Base64 string from eSewa into JSON
        const decodedJsonString = Buffer.from(encodedData, 'base64').toString('utf-8');
        const decodedData = JSON.parse(decodedJsonString);

        console.log('[eSewa Callback Data]:', decodedData);

        const { status, total_amount, transaction_uuid, product_code, signature, signed_field_names } = decodedData;

        // Check if payment status is COMPLETE
        if (status !== 'COMPLETE') {
            console.log(`[eSewa] Payment status is ${status}, not COMPLETE.`);
            return res.redirect(`${process.env.FRONTEND_URL}/sujanfrontend.html?payment=failed&reason=incomplete`);
        }

        // VERIFY SIGNATURE FROM ESEWA TO ENSURE NO TAMPERING
        // Reconstruct message from signed_field_names sent by eSewa
        const fieldNames = signed_field_names.split(',');
        const messageParts = fieldNames.map(field => `${field}=${decodedData[field]}`);
        const reconstructedMessage = messageParts.join(',');

        const hmac = crypto.createHmac('sha256', process.env.ESEWA_SECRET_KEY);
        hmac.update(reconstructedMessage);
        const expectedSignature = hmac.digest('base64');

        if (signature !== expectedSignature) {
            console.error('[eSewa Security Alert] Signature mismatch! Possible tampering.');
            return res.redirect(`${process.env.FRONTEND_URL}/sujanfrontend.html?payment=failed&reason=invalid_signature`);
        }

        console.log(`✅ [eSewa Verified] Payment of NPR ${total_amount} successful for order ${transaction_uuid}`);

        // Redirect user back to frontend with success parameters
        return res.redirect(`${process.env.FRONTEND_URL}/sujanfrontend.html?payment=success&gateway=esewa&ref=${transaction_uuid}&amount=${total_amount}`);

    } catch (error) {
        console.error('[eSewa Verification Error]:', error);
        return res.redirect(`${process.env.FRONTEND_URL}/sujanfrontend.html?payment=failed&reason=server_error`);
    }
});

// Endpoint 3: eSewa Payment Failure Callback
app.get('/api/esewa/failure', (req, res) => {
    console.log('[eSewa] Payment was cancelled or failed by user.');
    return res.redirect(`${process.env.FRONTEND_URL}/sujanfrontend.html?payment=cancelled&gateway=esewa`);
});

/**
 * ==============================================================================
 * SECTION 2: KHALTI PAYMENT GATEWAY (v2 API)
 * ==============================================================================
 * 
 * Khalti v2 Payment Flow:
 * 1. Frontend sends payment details to POST /api/khalti/initiate
 * 2. Backend makes server-to-server POST request to Khalti ePayment initiate API with Secret Key
 * 3. Khalti returns payment_url and pidx (payment index)
 * 4. Backend sends payment_url to frontend -> Frontend redirects user to Khalti portal
 * 5. User pays on Khalti -> Khalti redirects to GET /api/khalti/callback with pidx
 * 6. Backend makes server-to-server lookup POST request to Khalti API to verify status
 */

// Endpoint 4: Initiate Khalti Payment
app.post('/api/khalti/initiate', async (req, res) => {
    try {
        const { amount, purchase_order_id, purchase_order_name, customer_info } = req.body;

        if (!amount || amount <= 0) {
            return res.status(400).json({ success: false, message: 'Invalid payment amount' });
        }

        // Khalti expects amount in PAISA (1 NPR = 100 Paisa). Example: Rs 14,999 -> 1499900 Paisa
        const amountInPaisa = Math.round(Number(amount) * 100);

        // Khalti API Request Payload
        const khaltiPayload = {
            return_url: `${process.env.BACKEND_URL}/api/khalti/callback`,
            website_url: process.env.FRONTEND_URL,
            amount: amountInPaisa,
            purchase_order_id: purchase_order_id || `order-${Date.now()}`,
            purchase_order_name: purchase_order_name || "Wedding Photography Session",
            customer_info: customer_info || {
                name: "Valued Customer",
                email: "customer@example.com",
                phone: "9800000000"
            }
        };

        console.log(`[Khalti] Initiating payment for NPR ${amount} (${amountInPaisa} paisa)`);

        // Send POST request to Khalti API with secret key authorization header
        const response = await axios.post(
            process.env.KHALTI_INITIATE_URL || "https://a.khalti.com/api/v2/epayment/initiate/",
            khaltiPayload,
            {
                headers: {
                    'Authorization': `Key ${process.env.KHALTI_SECRET_KEY}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        console.log('[Khalti Response]:', response.data);

        // Khalti returns { pidx: "...", payment_url: "https://pay.khalti.com/?pidx=..." }
        return res.json({
            success: true,
            payment_url: response.data.payment_url,
            pidx: response.data.pidx
        });

    } catch (error) {
        console.error('[Khalti Error] Initiation failed:', error.response?.data || error.message);
        return res.status(500).json({
            success: false,
            message: 'Failed to initiate Khalti payment',
            details: error.response?.data || error.message
        });
    }
});

// Endpoint 5: Khalti Payment Callback (Verification via Lookup API)
app.get('/api/khalti/callback', async (req, res) => {
    try {
        // Khalti appends query parameters upon return: ?pidx=...&status=Completed&txnId=...
        const { pidx, status, transaction_id, amount } = req.query;

        if (!pidx) {
            return res.status(400).send('Missing pidx in Khalti callback');
        }

        console.log(`[Khalti Callback Received] Checking status for pidx: ${pidx}`);

        // SERVER-TO-SERVER VERIFICATION WITH KHALTI LOOKUP API
        const lookupResponse = await axios.post(
            process.env.KHALTI_LOOKUP_URL || "https://a.khalti.com/api/v2/epayment/lookup/",
            { pidx: pidx },
            {
                headers: {
                    'Authorization': `Key ${process.env.KHALTI_SECRET_KEY}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        console.log('[Khalti Lookup Result]:', lookupResponse.data);

        // Check if Khalti status is "Completed"
        if (lookupResponse.data.status === 'Completed') {
            const verifiedAmountNpr = (lookupResponse.data.total_amount || 0) / 100;
            console.log(`✅ [Khalti Verified] Payment of NPR ${verifiedAmountNpr} complete!`);

            // Redirect user back to frontend with success details
            return res.redirect(`${process.env.FRONTEND_URL}/sujanfrontend.html?payment=success&gateway=khalti&ref=${lookupResponse.data.transaction_id || pidx}&amount=${verifiedAmountNpr}`);
        } else {
            console.log(`[Khalti] Payment status verified as: ${lookupResponse.data.status}`);
            return res.redirect(`${process.env.FRONTEND_URL}/sujanfrontend.html?payment=failed&reason=${lookupResponse.data.status}`);
        }

    } catch (error) {
        console.error('[Khalti Lookup Verification Error]:', error.response?.data || error.message);
        return res.redirect(`${process.env.FRONTEND_URL}/sujanfrontend.html?payment=failed&reason=verification_error`);
    }
});

// START SERVER
app.listen(PORT, () => {
    console.log(`
  =============================================================
  🚀 WEDDING PHOTOGRAPHY PAYMENT SERVER STARTED SUCCESSFULLY!
  =============================================================
  📍 Server running at: http://localhost:${PORT}
  💳 eSewa Endpoint:   http://localhost:${PORT}/api/esewa/initiate
  💜 Khalti Endpoint:  http://localhost:${PORT}/api/khalti/initiate
  =============================================================
    `);
});
